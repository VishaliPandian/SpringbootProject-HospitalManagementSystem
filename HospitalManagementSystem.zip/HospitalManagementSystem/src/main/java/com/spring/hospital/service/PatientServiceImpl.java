package com.spring.hospital.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.PatientNotFoundException;
import com.spring.hospital.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService {
	@Autowired
	private PatientRepository patientRepository;

	@Override
	public Patient addPatient(@Valid Patient patient) {
		// TODO Auto-generated method stub
		return patientRepository.save(patient);
	}

	@Override
	public Patient getPatientById(Long patientId) throws PatientNotFoundException  {
		Optional<Patient> patient=patientRepository.findById(patientId) ;
		
		 if(!patient.isPresent()) {
			 throw new PatientNotFoundException("Patient Not Found");
		 }
		// TODO Auto-generated method stub
		return patientRepository.findById(patientId).get();
	}

	@Override
	public List<Patient> getAllPatient() {
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}

	@Override
	public Patient patientUpdateById(Long patientId, Patient patient) throws PatientNotFoundException {
		// TODO Auto-generated method stub
		Optional<Patient> pat=patientRepository.findById(patientId) ;
		Patient patientDB;
		if(!pat.isPresent()) {
			 throw new PatientNotFoundException("Patient Not Found");
		 }
		
		 else{
		         patientDB=patientRepository.findById(patientId).get();
				
				if(Objects.nonNull(patient.getPatientName()) &&
				!"".equalsIgnoreCase(patient.getPatientName())) {
					patientDB.setPatientName(patient.getPatientName());
				}
				if(Objects.nonNull(patient.getPatientFname()) &&
						!"".equalsIgnoreCase(patient.getPatientFname())) {
							patientDB.setPatientFname(patient.getPatientFname());
						}
				if(Objects.nonNull(patient.getGender()) &&
						!"".equalsIgnoreCase(patient.getGender())) {
							patientDB.setGender(patient.getGender());
						}
				if(Objects.nonNull(patient.getBloodGroup()) &&
						!"".equalsIgnoreCase(patient.getBloodGroup())) {
							patientDB.setBloodGroup(patient.getBloodGroup());
						}
				if(Objects.nonNull(patient.getAddress()) &&
						!"".equalsIgnoreCase(patient.getAddress())) {
							patientDB.setAddress(patient.getAddress());
						}
	
					}
		return patientRepository.save(patientDB);
	}

	@Override
	public void patientDeleteById(Long patientId) throws PatientNotFoundException {
		// TODO Auto-generated method stub
		Optional<Patient> pat=patientRepository.findById(patientId) ;
		if(!pat.isPresent()) {
			 throw new PatientNotFoundException("Doctor Not Found");
		 }
		patientRepository.deleteById(patientId);
		}



		
	}
	
	
	


