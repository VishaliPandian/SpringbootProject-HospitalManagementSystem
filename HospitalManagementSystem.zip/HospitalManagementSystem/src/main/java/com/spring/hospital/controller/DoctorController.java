package com.spring.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.spring.hospital.entity.Doctor;
import com.spring.hospital.error.DoctorNotFoundException;
import com.spring.hospital.service.DoctorService;

@RestController
public class DoctorController {
	@Autowired
	private DoctorService doctorService;
	
//save the record
   
   @PostMapping("/doctor")  //http://localhost:portno/doctor
   public Doctor saveDcotor(@RequestBody Doctor doctor) {
   return doctorService.saveDoctor(doctor);
   }

//get  records by id

	@GetMapping("/doctor/{doctorid}") //http://localhost:8889/doctor/1
	public Doctor getDoctorById(@PathVariable("doctorid") Long doctorId) throws DoctorNotFoundException {
		return doctorService.getDoctorById(doctorId);
	}
	
//get all doctor
		@GetMapping("/getAllDoctor")
		public List<Doctor> getAllDoctor(){
			return doctorService.getAllDoctor();
		}
		
//update doctor detail
		@PutMapping("/doctor/{doctorid}")
		public Doctor doctorUpdateById(@PathVariable("doctorid") Long doctorId,@RequestBody Doctor doctor ) throws DoctorNotFoundException {
			return doctorService.doctorUpdateById(doctorId,doctor);
		}
//delete doctor detail
		@DeleteMapping("/doctor/{doctorid}")
		public String doctorDeleteById(@PathVariable("doctorid") Long doctorId) throws DoctorNotFoundException {
			doctorService.doctorDeleteById(doctorId);
			return "Doctor is deleted";
		}
}
