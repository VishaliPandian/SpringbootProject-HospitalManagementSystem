package com.spring.hospital.error;

public class PatientNotFoundException  extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientNotFoundException(String s) {
		super(s);
	}


}
