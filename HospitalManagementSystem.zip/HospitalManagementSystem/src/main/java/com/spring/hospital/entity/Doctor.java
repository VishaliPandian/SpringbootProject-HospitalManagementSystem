package com.spring.hospital.entity;


import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer doctorId;
	private String doctorName;
	private String doctorFname;
	private String Gender;
	private String Address;
	private String Designation;
	
	
//connection to patient table using doctor id
	@JsonIgnore
     @OneToMany(mappedBy="doctor")
     private Set<Patient> patient=new HashSet<>();
     public Set<Patient> getPatient() {
 		return patient;
 	}
 	public void setPatient(Set<Patient> patient) {
 		this.patient = patient;
 	}
     
    
	//constructor without argument
	public Doctor() {
		super();
	}
	
	//constructor with argument
	public Doctor(Integer doctorId, String doctorName, String doctorFname, String gender, String address,
			String designation) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFname = doctorFname;
		this.Gender = gender;
		this.Address = address;
		this.Designation = designation;
	}
	
	//getter and setter
	public Integer getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorFname() {
		return doctorFname;
	}
	public void setDoctorFname(String doctorFname) {
		this.doctorFname = doctorFname;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		this.Gender = gender;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		this.Designation = designation;
	}
	
	//to string generation
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorFname=" + doctorFname
				+ ", Gender=" + Gender + ", Address=" + Address + ", Designation=" + Designation + "]";
	}

}
