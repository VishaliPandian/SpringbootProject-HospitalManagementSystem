package com.spring.hospital.service;

import java.util.List;
import com.spring.hospital.entity.Doctor;
import com.spring.hospital.error.DoctorNotFoundException;

public interface DoctorService {

public	Doctor saveDoctor(Doctor doctor);

public Doctor getDoctorById(Long doctorId) throws DoctorNotFoundException;

public List<Doctor> getAllDoctor();

public Doctor doctorUpdateById(Long doctorId, Doctor doctor) throws DoctorNotFoundException;

public void doctorDeleteById(Long doctorId) throws DoctorNotFoundException;

}
