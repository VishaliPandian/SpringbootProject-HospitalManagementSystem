package com.spring.hospital.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.hospital.entity.Doctor;
import com.spring.hospital.error.DoctorNotFoundException;
import com.spring.hospital.repository.DoctorRepository;
@Service
public class DoctorServiceImpl implements DoctorService {
	@Autowired
	private DoctorRepository doctorRepository;

	@Override
	public Doctor saveDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorRepository.save(doctor);
	}

	@Override
	public Doctor getDoctorById(Long doctorId) throws DoctorNotFoundException {
		Optional<Doctor> doctor=doctorRepository.findById(doctorId) ;
		
		 if(!doctor.isPresent()) {
			 throw new DoctorNotFoundException("Doctor Not Found");
		 }
		 return doctorRepository.findById(doctorId).get();
		
	}

	@Override
	public List<Doctor> getAllDoctor() {
		// TODO Auto-generated method stub
		return doctorRepository.findAll();
	}

	@Override
	public Doctor doctorUpdateById(Long doctorId, Doctor doctor) throws DoctorNotFoundException {
		// TODO Auto-generated method stub
		Optional<Doctor> doct=doctorRepository.findById(doctorId) ;
		Doctor doctorDB;
		if(!doct.isPresent()) {
			 throw new DoctorNotFoundException("Doctor Not Found");
		 }
		
		 else{
		         doctorDB=doctorRepository.findById(doctorId).get();
				
				if(Objects.nonNull(doctor.getDoctorName()) &&
				!"".equalsIgnoreCase(doctor.getDoctorName())) {
					doctorDB.setDoctorName(doctor.getDoctorName());
				}
				if(Objects.nonNull(doctor.getDoctorFname()) &&
						!"".equalsIgnoreCase(doctor.getDoctorFname())) {
							doctorDB.setDoctorFname(doctor.getDoctorFname());
						}
				if(Objects.nonNull(doctor.getGender()) &&
						!"".equalsIgnoreCase(doctor.getGender())) {
							doctorDB.setGender(doctor.getGender());
						}
				if(Objects.nonNull(doctor.getAddress()) &&
						!"".equalsIgnoreCase(doctor.getAddress())) {
							doctorDB.setAddress(doctor.getAddress());
						}
				if(Objects.nonNull(doctor.getDesignation()) &&
						!"".equalsIgnoreCase(doctor.getDesignation())) {
							doctorDB.setDesignation(doctor.getDesignation());
						}
					}
		         return doctorRepository.save(doctorDB);
	}
		@Override
		public void doctorDeleteById(Long doctorId) throws DoctorNotFoundException  {
		//	departmentRepository.deleteById(departmentId);
			Optional<Doctor> doct=doctorRepository.findById(doctorId) ;
			if(!doct.isPresent()) {
				 throw new DoctorNotFoundException("Doctor Not Found");
			 }
			doctorRepository.deleteById(doctorId);
			}

       }
