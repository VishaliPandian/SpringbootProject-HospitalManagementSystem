package com.spring.hospital.service;

import java.util.List;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.PatientNotFoundException;

public interface PatientService {

	public Patient addPatient(Patient patient);
	public Patient getPatientById(Long patientId) throws PatientNotFoundException;
    public List<Patient> getAllPatient();
    public Patient patientUpdateById(Long patientId, Patient patient) throws PatientNotFoundException;
	public void patientDeleteById(Long patientId) throws PatientNotFoundException;
	
	
	

}
