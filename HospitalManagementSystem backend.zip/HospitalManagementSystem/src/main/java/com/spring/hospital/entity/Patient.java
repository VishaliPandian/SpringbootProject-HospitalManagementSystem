package com.spring.hospital.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer patientId;
	private String patientName;
	private String patientFname;
	private String gender;
	private String bloodGroup;
	private String problem;
	private String Address;
	private String phoneNo;
	
	//connection doctor table with doctor id
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="doctor_id" , referencedColumnName = "doctorId")
	@JsonIgnore
	private Doctor doctor;
	public Doctor getDoctor() {
		return doctor;
	    }
	    public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	     }
	
	//constructor without argument
	public Patient() {
		super();
	}
	public Patient(Integer patientId, String patientName, String patientFname, String gender, String bloodGroup,
			String problem, String address, String phoneNo) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientFname = patientFname;
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.problem = problem;
		this.Address = address;
		this.phoneNo = phoneNo;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientFname() {
		return patientFname;
	}
	public void setPatientFname(String patientFname) {
		this.patientFname = patientFname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientFname=" + patientFname
				+ ", gender=" + gender + ", bloodGroup=" + bloodGroup + ", problem=" + problem + ", Address=" + Address
				+ ", phoneNo=" + phoneNo + "]";
	}
	public void patientAssignDoctor(Doctor doctor) {
		this.doctor=doctor;
		
	}

	
	
}