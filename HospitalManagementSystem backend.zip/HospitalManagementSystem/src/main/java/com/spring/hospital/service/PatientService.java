package com.spring.hospital.service;

import java.util.List;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.PatientNotFoundException;

public interface PatientService {

	
	
    public List<Patient> findAllPatient();
	public List<Patient> patientDeleteById(Integer patientId);
	public Patient patientAssignDoctor(Integer patientid, Integer doctorid);
	public void patient(Patient patient);
	public Patient patientUpdateById(Integer patientId, Patient patient);
	//public List<Patient> findPatientById(Integer patientId);
	public List<Patient> getPatientById(Integer patientId);
	
	
	

}
