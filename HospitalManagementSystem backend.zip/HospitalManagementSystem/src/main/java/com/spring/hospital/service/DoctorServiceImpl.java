package com.spring.hospital.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.hospital.entity.Doctor;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.DoctorNotFoundException;
import com.spring.hospital.repository.DoctorRepository;
@Service
public class DoctorServiceImpl implements DoctorService {
	@Autowired
	private DoctorRepository doctorRepository;

	@Override
	public void doctor(Doctor doctor) {
		// TODO Auto-generated method stub
		doctorRepository.save(doctor);
	}

	@Override
	public List<Doctor> getDoctorById(Integer doctorId) {
		Doctor ob= doctorRepository.findById(doctorId).get();
		List<Doctor> d=new ArrayList<>();
		d.add(ob);
		return d;

		// return doctorRepository.findById(doctorId).get();
		
	}

	@Override
	public List<Doctor> findAllDoctor() {
		// TODO Auto-generated method stub
		return doctorRepository.findAll();
	}

	@Override
	public Doctor doctorUpdateById(Integer doctorId, Doctor doctor) {
		
		Doctor doct=doctorRepository.findById(doctorId).get();
				doct.setDoctorName(doctor.getDoctorName());
				doct.setDoctorFname(doctor.getDoctorFname());
				doct.setGender(doctor.getGender());
				doct.setAddress(doctor.getAddress());
				doct.setDesignation(doctor.getDesignation());
		         doctorRepository.save(doct);
		         return doct;
	}
		@Override
		public List<Doctor> doctorDeleteById(Integer doctorId)   {
	
			doctorRepository.deleteById(doctorId);
			return doctorRepository.findAll();
			}

       }
