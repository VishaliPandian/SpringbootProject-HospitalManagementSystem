package com.spring.hospital.service;

import java.util.List;
import com.spring.hospital.entity.Doctor;
import com.spring.hospital.error.DoctorNotFoundException;

public interface DoctorService {

public	void doctor(Doctor doctor);



public List<Doctor> doctorDeleteById(Integer doctorId);

public Doctor doctorUpdateById(Integer doctorId, Doctor doctor);

public List<Doctor> findAllDoctor();

//public List<Doctor> findDoctorById(Integer doctorId);



public List<Doctor> getDoctorById(Integer doctorId);




}
