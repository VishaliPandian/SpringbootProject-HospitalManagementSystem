package com.spring.hospital.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.PatientNotFoundException;
import com.spring.hospital.service.PatientService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PatientController {
	 @Autowired
	 private PatientService patientService;
	 //save record
	 @PostMapping("/patientregister") // http://localhost:8889/pa
	 public String patient( @RequestBody  Patient patient) {
		 patientService.patient(patient);
		   return "Hi"  +patient.getPatientName()+" patient field registeration successfully completed";
		   }
	 	
	 //get  records by id
		
		@GetMapping("/findpatient/{patientid}") //http://localhost:8889/patient/1
		public List<Patient> getPatientById(@PathVariable("patientid") Integer patientId) throws PatientNotFoundException {
		return patientService.getPatientById(patientId);
		}
		//get all patient details
				@GetMapping("/getAllPatient")
				public List<Patient> findAllPatient(){
					return patientService.findAllPatient();
					}
		//update patient
		@PutMapping("/updatepatient/{patientid}")
		public Patient patientUpdateById(@PathVariable("patientid") Integer patientId,@RequestBody Patient patient ) {
		return patientService.patientUpdateById(patientId,patient);
		}
		//delete patient by patient id
				@DeleteMapping("/deletepatient/{patientid}")
				public List<Patient> patientDeleteById(@PathVariable("patientid") Integer patientId) throws PatientNotFoundException {
					return patientService.patientDeleteById(patientId);
					
				}
		//assign patient to doctor
		@ResponseBody
				@PutMapping("/patientAssignDoctor/{patientid}/doctor/{doctortid}")
				public Patient patientAssignDoctor(@PathVariable Integer patientId, @PathVariable Integer doctorId) {
					  System.out.println("inside patientAssignDoctor");
					return patientService.patientAssignDoctor(patientId,doctorId);

					
				}
}
