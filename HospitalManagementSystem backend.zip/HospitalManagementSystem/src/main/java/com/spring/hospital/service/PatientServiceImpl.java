package com.spring.hospital.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.hospital.entity.Doctor;
import com.spring.hospital.entity.Patient;
import com.spring.hospital.error.PatientNotFoundException;
import com.spring.hospital.repository.DoctorRepository;
import com.spring.hospital.repository.PatientRepository;

@Service
public class PatientServiceImpl<Employee> implements PatientService {
	@Autowired
	private PatientRepository patientRepository;
	@Autowired
	private DoctorRepository doctorRepository;

	@Override
	public void patient (Patient patient) {
		// TODO Auto-generated method stub
	 patientRepository.save(patient);
	}

	@Override
	public List<Patient> getPatientById(Integer patientId)  {
	
		// TODO Auto-generated method stub
		Patient pob= patientRepository.findById(patientId).get();
		List<Patient> p=new ArrayList<>();
		p.add(pob);
		return p;
	}

	@Override
	public List<Patient> findAllPatient() {
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}

	@Override
	public Patient patientUpdateById(Integer patientId, Patient patient)  {
		
		Patient pat=patientRepository.findById(patientId).get();
		pat.setPatientName(patient.getPatientName());
		pat.setPatientFname(patient.getPatientFname());
		pat.setGender(patient.getGender());
		pat.setBloodGroup(patient.getBloodGroup());
		pat.setProblem(patient.getProblem());
		pat.setAddress(patient.getAddress());
		pat.setPhoneNo(patient.getPhoneNo());		
		patientRepository.save(pat);
		return pat;
	}

	@Override
	public List<Patient> patientDeleteById(Integer patientId) {
		patientRepository.deleteById(patientId);
		return patientRepository.findAll();
		}

	@Override
	public Patient patientAssignDoctor(Integer patientId, Integer doctorId) {
		// TODO Auto-generated method stub
		Doctor doctor=doctorRepository.findById(doctorId).get();
		Patient patient=patientRepository.findById(patientId).get();
		patient.patientAssignDoctor(doctor);
		return patientRepository.save(patient);
	}



		
	}
	
	
	


